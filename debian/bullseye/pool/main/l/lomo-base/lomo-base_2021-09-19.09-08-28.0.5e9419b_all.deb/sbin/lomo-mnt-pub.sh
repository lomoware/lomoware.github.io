#! /bin/bash
set -e

trap "exit" INT

INTERVAL=180

while true; do
    devices=($(mount | grep "^/dev/sd" | cut -d ' ' -f3))
    mnt=$(printf ":%s" "${devices[@]}")
    mnt=${mnt:1}
    if [ ! -z "$mnt" ]
    then
        txt="path=$mnt"
        echo $txt
        timeout -s SIGINT $INTERVAL avahi-publish-service lomo _lomosmb._tcp 0 $txt
    fi
    sleep 3
done
