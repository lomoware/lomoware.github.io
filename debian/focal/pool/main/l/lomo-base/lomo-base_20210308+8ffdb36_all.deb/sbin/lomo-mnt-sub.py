#!/usr/bin/env python3
import subprocess
import os
import time

def probe():
    cmd = 'avahi-browse -rtp _lomosmb._tcp | grep IPv4 | grep lomorage | cut -d ";" -f8,10'
    ps = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE, universal_newlines=True)
    out, err = ps.communicate()
    if err.strip() != "":
        print("probe error: %s" % err)
        return []

    records = []
    for l in out.splitlines():
        # expect something like 192.168.1.200;"path=/media/WD_36AA8D42AA8D001B:/media/WD_90C27F73C27F5C82"
        g = l.strip().split(";")
        if len(g) == 2:
            ip = g[0]
            mpath = g[1].strip('"').split("=")[1]
            mpaths = mpath.split(":")
            print("found ip: %s, path: %s" % (ip, mpaths))
            if mpath != '':
                records.append((ip, mpaths))
            else:
                print("warn: invalid path")
        else:
            print("format error: %s" % out)
            break

    return records

def mount(ip, mpath):
    '''
    sudo mkdir /media/WD_90C27F73C27F5C82
    sudo mount.cifs //192.168.1.155/media/WD_90C27F73C27F5C82 /media/WD_90C27F73C27F5C82 -o user=pi,pass=raspberry,uid=1000,gid=1000
    '''
    print("mount %s %s ..." % (ip, mpath))

    os.system("sudo mkdir -p %s" % mpath)
    if not os.path.exists(mpath):
        print("error: can't creat %s" % mpath)
        return
    else:
        if not os.path.isdir(mpath):
            print("error: %s is not directory" % mpath)
            return

    cmd = 'mount | grep "%s"' % mpath
    ps = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE, universal_newlines=True)
    out, err = ps.communicate()
    if err.strip() != "":
        print("check existing mount error: %s" % err)
    mounted = out.strip()
    if mounted != "":
        print("skip, %s already mounted" % mpath)
        return

    cmd = 'sudo mount.cifs //%s%s %s -o user=pi,pass=raspberry,uid=1000,gid=1000' % (ip, mpath, mpath)
    print(cmd)
    ps = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE, universal_newlines=True)
    out, err = ps.communicate()
    if err.strip() != "":
        print("mount error: %s" % err)
        return

    print("mount succ")
    os.system("ls %s" % mpath)

def clean(mpaths_all):
    dirname = '/media'
    print('clean %s...' % dirname)
    if os.path.exists(dirname) and os.path.isdir(dirname):
        for d in os.listdir(dirname):
            dpath = os.path.join(dirname, d)
            if dpath not in mpaths_all:
                if not os.listdir(dpath):
                    print("%s not mounted and it's empty, can remove" % dpath)
                    #os.system("sudo rm -rf %s" % dpath)
            else:
                # check if it's local mount
                pass

def auto_mount():
    records = probe()
    mpaths_all = []
    for r in records:
        (ip, mpaths) = r
        mpaths_all.extend(mpaths)
        for mpath in mpaths:
            mount(ip, mpath)

    #clean(mpaths_all)

if __name__ == '__main__':
    while True:
        auto_mount()
        time.sleep(180)
